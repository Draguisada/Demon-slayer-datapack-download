There's two version of the resouce pack. One without GUI changes, like the Hotbar and the crosshair change. Nothing more changes.
Algo credits to the Hotbar gui, jotacincoj5 made it